using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;
using System.Linq;
public class P2 : MonoBehaviour
{
    private void OnEnable() 
    {
   
        UIDocument UIdoc = GetComponent<UIDocument>();
        VisualElement rootve = UIdoc.rootVisualElement;
        Button butonbluered = rootve.Query<Button>("Bluetored");
        Button butonbluegreen = rootve.Query<Button>("Bluetogreen");
        Button butonredgreen = rootve.Query<Button>("Redtogreen");
        Button butonredblue = rootve.Query<Button>("Redtoblue");
        Button butongreenblue = rootve.Query<Button>("Greentoblue");
        Button butongreenred = rootve.Query<Button>("Greentored");


        butonbluered.clicked += () => DisplayRed(rootve);
        butonbluegreen.clicked += () => DisplayGreen(rootve);
        butonredgreen.clicked += () => DisplayGreen(rootve);
        butonredblue.clicked += () => DisplayBlue(rootve);
        butongreenblue.clicked += () => DisplayBlue(rootve);
        butongreenred.clicked += () => DisplayRed(rootve);

  



        Button buton = rootve.Query<Button>("BlueButton");
        buton.AddToClassList("button");
        buton.clicked += ()=> buton.style.scale = new Scale( new Vector3(1.5f, 1.5f, 1.5f));

        Scroller slider = rootve.Query<Scroller>().First();
        slider.AddToClassList("slider"); slider.RemoveFromClassList("unity-scroller"); slider.RemoveFromClassList("unity-scroller--horizontal");

        ProgressBar progress = rootve.Query<ProgressBar>().First();
        progress.AddToClassList("progress"); progress.RemoveFromClassList("unity-progress-bar");
    }
    void DisplayBlue(VisualElement rootve) 
    {
        VisualElement blue = rootve.Query(className: "blue").Last();
        VisualElement red = rootve.Query(className: "red").Last();
        VisualElement green = rootve.Query(className: "green").Last();
        blue.style.display = DisplayStyle.Flex;
        red.style.display = DisplayStyle.None;
        green.style.display = DisplayStyle.None;

    }
    void DisplayGreen(VisualElement rootve)
    {
        VisualElement green = rootve.Query(className: "green").Last();
        VisualElement blue = rootve.Query(className: "blue").Last();
        VisualElement red = rootve.Query(className: "red").Last();
        green.style.display = DisplayStyle.Flex;
        red.style.display = DisplayStyle.None;
        blue.style.display = DisplayStyle.None;


    }
    void DisplayRed(VisualElement rootve)
    {
        VisualElement red = rootve.Query(className: "red").Last();
        VisualElement blue = rootve.Query(className: "blue").Last();
        VisualElement green = rootve.Query(className: "green").Last();
        red.style.display = DisplayStyle.Flex;
        green.style.display = DisplayStyle.None;
        blue.style.display = DisplayStyle.None;


    }

}
